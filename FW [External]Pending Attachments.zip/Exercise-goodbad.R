# Classification Trees using rpart

library(dplyr)
library(rpart)
library(caret)
library(irr)

#Tree plotting
library(rattle)
library(rpart.plot)
library(RColorBrewer)


#load  dataset

setwd("E:\\Jaishree\\Data Science with R\\Datasets")
goodbad <- read.table("goodbad.txt", header = T)
goodbad

str(goodbad)
summary(goodbad)
dim(goodbad)

# Target variable is goodbad

table(goodbad$GoodBad)

colSums(is.na(goodbad))

# No missing values

# Recursive Partitioning and Regression Trees

fit <- rpart(GoodBad ~ ., 
             data = goodbad,
             method = "class",
             control=rpart.control(cp = 0.002, maxdepth = 3 ),
             parms = list(split="gini"))

# Any split which does not improve the fit, for example
# gini, by complexity paramter,cp, is likely to be 
# pruned off or is not attempted

# parms is a list of algorithms to be used 

# The splitting index can be gini or Entropy in R.
# Gini Method is the default method 
# split = "information" for Information gain

plot(fit, margin=0.1, main = "Classification tree for goodbad")
text(fit, use.n = TRUE, all = TRUE, cex = 0.7)

#Prettier way of plotting tree

fancyRpartPlot(fit, main="Decision Tree")

fit

# Terminal nodes are 4,10,11,12,13
 

# Confusion Matrix

actual<-goodbad$GoodBad
predicted<-predict(fit,type = "class")

head(predicted)

confusionMatrix(as.factor(actual),predicted,positive="1")

#Accuracy is 74%

library(ROCR)
#AUC

?prediction
pred<-prediction(actual, as.integer(predicted))
perf<-performance(pred,"tpr","fpr")
plot(perf,col="red")
abline(0,1, lty = 8, col = "grey")

auc<-performance(pred,"auc")
unlist(auc@y.values)

