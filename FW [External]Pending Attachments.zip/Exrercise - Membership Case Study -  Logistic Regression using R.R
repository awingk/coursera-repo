
#-------Importing the data---------
setwd("E:\\Jaishree\\Data Science with R\\Datasets")

club =read.csv('membership.csv',na.strings = c(""," ","NA"))

# Data Exploration

str(club)
dim(club)
summary(club)

# Marital Status has 2597 NA's
# Gender has 611 NA's
# Occupation code has 43 missing values

#Member ship term Deciles
quantile(club$MEMBERSHIP_TERM_YEARS, probs =seq(0,1,0.1))

# Annual Fee Percentiles
quantile(club$ANNUAL_FEES, probs =seq(0,1,0.01))

# Outliersin Annual Fee after 96%

# Annual Income Percentiles

quantile(club$MEMBER_ANNUAL_INCOME, probs =seq(0,1,0.01), na.rm = TRUE)

# Outliers after 99%

## Data Preparation

# Imputing missing values in Marital status with 'Missing'

club$MEMBER_MARITAL_STATUS <- as.character(club$MEMBER_MARITAL_STATUS)
club$MEMBER_MARITAL_STATUS[is.na(club$MEMBER_MARITAL_STATUS)]<- "Missing"
club$MEMBER_MARITAL_STATUS <- as.factor(club$MEMBER_MARITAL_STATUS)
summary(club$MEMBER_MARITAL_STATUS)

# Imputing missing values in Gender with 'Missing'

club$MEMBER_GENDER <- as.character(club$MEMBER_GENDER)
club$MEMBER_GENDER[is.na(club$MEMBER_GENDER)]<- "Missing"
club$MEMBER_GENDER <- as.factor(club$MEMBER_GENDER)
summary(club$MEMBER_GENDER)

# Removing missing values in Occupation Codes

index <- which(is.na(club$MEMBER_OCCUPATION_CD))
club <- club[-index,]
summary(club$MEMBER_OCCUPATION_CD)
dim(club)

#Imputing outliers in Annual Fee with 96% percentile value

club$ANNUAL_FEES[club$ANNUAL_FEES>500000] <- 500000
summary(club$ANNUAL_FEES)

# Imputing outliers in Annual Income with 99% percentile value

club$MEMBER_ANNUAL_INCOME[club$MEMBER_ANNUAL_INCOME > 9000000] <- 9000000

# Imputing missing values in Annual Income with mean

club$MEMBER_ANNUAL_INCOME[is.na(club$MEMBER_ANNUAL_INCOME)] <- mean(club$MEMBER_ANNUAL_INCOME, na.rm = T)
summary(club$MEMBER_ANNUAL_INCOME)

# Creating a dependent variable called TARGET with 1,0 values to identify good customers at risk

summary(club$MEMBERSHIP_STATUS)
club$Target<-ifelse(club$MEMBERSHIP_STATUS=='CANCELLED',1,0)


#1=At risk, 0=Not at risk

# How many members are at risk?

# Frequency Distribution of the binary dependent variable 

table(club$Target)

# 3135 are at risk and 7184 not at risk


# Partition the dataset into training and validation dataset

sampling<-sort(sample(nrow(club), nrow(club)*.7))

length(sampling)

#Row subset and create training and validation samples using the index numbers

train<-club[sampling,]
test<-club[-sampling,]
nrow(train)
nrow(test)

# Checking the frequency Distribution of the target variable 

#Table of y for the train dataset. To find the percentages, I am dividing by 700 and 300 respectively

table(train$Target)
table(train$Target)/7223*100
table(test$Target)/3096*100


#Run the Logistic Regression model

#Iteration 1

names(club)

myresult<-glm(data=train,Target ~ MEMBERSHIP_TERM_YEARS+
                ANNUAL_FEES + MEMBER_MARITAL_STATUS+
                MEMBER_GENDER+MEMBER_ANNUAL_INCOME+
                MEMBER_OCCUPATION_CD+MEMBERSHIP_PACKAGE+
                MEMBER_AGE_AT_ISSUE+ADDITIONAL_MEMBERS+
                PAYMENT_MODE,
              family=binomial)

summary(myresult)


# Dispersion parameter for binomial family taken to be 1 meaning that the predicted values are probabilities that the customer is at risk

reduced<-step(myresult,direction="backward")

#Iteration # 2:

# Retain MEMBERSHIP_TERM_YEARS + ANNUAL_FEES + 
# MEMBER_MARITAL_STATUS + MEMBER_GENDER + 
# MEMBER_ANNUAL_INCOME + MEMBERSHIP_PACKAGE + 
#  MEMBER_AGE_AT_ISSUE + ADDITIONAL_MEMBERS + PAYMENT_MODE

myresult<-glm(data=train,Target ~ MEMBERSHIP_TERM_YEARS+
                ANNUAL_FEES + MEMBER_MARITAL_STATUS+
                MEMBER_GENDER+MEMBER_ANNUAL_INCOME+
                MEMBERSHIP_PACKAGE+MEMBER_AGE_AT_ISSUE+
                ADDITIONAL_MEMBERS+PAYMENT_MODE,
              family=binomial)

summary(myresult)

# Iteration 3:

# Create dummy variables for Membership Package B, Payment Mode - qrtly and annual

train$PackageB = ifelse(train$MEMBERSHIP_PACKAGE == 'TYPE-B',1,0)
train$PayQ = ifelse(train$PAYMENT_MODE == 'QUARTERLY',1,0)
train$PayA = ifelse(train$PAYMENT_MODE == 'ANNUAL',1,0)
train$Male = ifelse(train$MEMBER_GENDER == 'M',1,0)


myresult<-glm(data=train,Target ~ MEMBERSHIP_TERM_YEARS+
                ANNUAL_FEES + Male+
                MEMBER_ANNUAL_INCOME+PackageB+
                MEMBER_AGE_AT_ISSUE+
                ADDITIONAL_MEMBERS+PayQ+PayA,
              family=binomial)

summary(myresult)

#Finding Predicted Values

predicted <- myresult$fitted.values
class(predicted)
head(predicted)
length(predicted)

# Compare with actual data

head(train$Target)

# Let us convert the probabilities also into Good/Bad response based on a cut-off probability

#Confusion Matrix
predbkt<-ifelse(predicted>0.5,'At risk','Not at Risk')
table(predbkt,train$Target)


# At 0.5 cut-off probability:-
# 159  customers were predicted as "at risk' correctly - "True Positive"
# 4861 customers were predicted as "not at risk"correctly - "True Negatives"

#True Positive+ True Negative should be high. 

# Accuracy = (TP+TN)/(P+N)

(153+4894)/(153+4894+159+2017)


# For different cutoff probabilities, the confusion matrix will be different


# There are a lot of performance parameters available in ROCR package

library(ROCR)


# The prediction function of the ROCR library basically creates a structure to validate our predictions with actual values

pred<-prediction(predicted,train$Target)

?performance

perf <- performance(pred,"acc")
perf
# x values contain the cut-off probabilities

#use @ to access the slots

class(perf@x.values)
cutoffprob <- as.numeric(unlist(perf@x.values))


class(perf@y.values)
accuracies <- as.numeric(unlist(perf@y.values))

cutoffs <- data.frame(cutoffprob, accuracies )
# In the decreasing order of accuracy
cutoffs <- cutoffs[order(cutoffs$accuracies, decreasing=TRUE),]

# Accuracy is highest at 0.5462127

train$predbkt<-ifelse(predicted>0.4617141,1,0)
table(train$predbkt,train$Target)

library(caret)
library(irr)

confusionMatrix(as.factor(train$Target),as.factor(train$predbkt), positive = "1")


# To find true positive rate and false positive rate
# TPR = TP/P
# FPR = FP/N

71/(71+2133)
62/(62+4960)

## computing a simple ROC curve (x-axis: fpr, y-axis: tpr)

perf<-performance(pred,"tpr","fpr") #tpr=TP/P fpr=FP/N
plot(perf,col="red")
# Receiver Operating Characteristic Curve (ROC) a plot of TPR versus FPR for the possible cut-off classification probability values.A good ROC curve should be almost vertical in the beginning and almost horizontal in the end.
# "tpr" and "fpr" are arguments of the "performance" function indicating that the plot is between the true positive rate and the false positive rate.

?abline
# Draw a straight line with intercept 0 and slope = 1
# The straight line is a random chance line
# ROC curve should be higher than the AB line

abline(0,1, lty = 8, col = "blue")


# Area under the curve should be more than 50%

auc<-performance(pred,"auc")
auc


