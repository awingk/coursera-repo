
library(dplyr)

setwd("E:\\Jaishree\\Data Science with R\\Datasets")
rfm <- read.csv("rfm.csv", header = T, stringsAsFactors = F)

# Data Exploration

dim(rfm)

# 1471 customers and 5 variables

str(rfm)
View(rfm)

# Data Summaries

summary(rfm)

# No missing values

# Check for outliers

boxplot(rfm$ASP)


quantile(rfm$ASP, p = seq(0,1,0.01))


summary(rfm)

# Different variables have different scales

# Data Preparation
# Pick the numeric variables that are to be scaled

rfmnum <- rfm[,c(2,3,4,5)]
str(rfmnum)

# Scaling - standardize the data to a common scale


?scale
rfmscale <- scale(rfmnum, center = T, scale = T)
rfmscaledf= data.frame(rfmscale)
class(rfmscaledf)
summary(rfmscaledf)
View(rfmscaledf)


# Weighting - Skipping weighting

# Set the seed so that every time clustering is done, we get the same output

set.seed(1234)

# K-Means clustering

?kmeans
cluster4= kmeans(rfmscaledf, centers = 4, iter.max = 40)
cluster4

str(cluster4)

# Size of the clusters

cluster4$size


cluster4$cluster

# Compare strength and sizes of different sets of clusters and find the optimal one


# Adding cluster numbers to original dataset

rfm$cluster <- cluster4$cluster
View(rfm)

# Profiling follows clustering

clust1 <- rfm[rfm$cluster == 1,]
clust1summary<-summary(clust1)
clust1summary

clust2 <- rfm[rfm$cluster == 2,]
summary(clust2)

clust3 <- rfm[rfm$cluster == 3,]
summary(clust3)

clust4 <- rfm[rfm$cluster == 4,]
summary(clust4)

summary(rfm)
sd(rfm$ASP)
sd(rfm$Recency)
sd(rfm$Frequency)
sd(rfm$Monetary)

